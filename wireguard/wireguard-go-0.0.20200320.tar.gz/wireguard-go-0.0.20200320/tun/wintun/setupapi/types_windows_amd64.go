/* SPDX-License-Identifier: MIT
 *
 * Copyright (C) 2019 WireGuard LLC. All Rights Reserved.
 */

package setupapi

const (
	sizeofDevInfoListDetailData uint32 = 560
	sizeofDrvInfoDetailData     uint32 = 1584
)
