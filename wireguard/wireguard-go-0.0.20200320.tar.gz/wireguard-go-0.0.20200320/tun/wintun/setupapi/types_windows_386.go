/* SPDX-License-Identifier: MIT
 *
 * Copyright (C) 2019 WireGuard LLC. All Rights Reserved.
 */

package setupapi

const (
	sizeofDevInfoListDetailData uint32 = 550
	sizeofDrvInfoDetailData     uint32 = 1570
)
