package device

const WireGuardGoVersion = "0.0.20200320"
