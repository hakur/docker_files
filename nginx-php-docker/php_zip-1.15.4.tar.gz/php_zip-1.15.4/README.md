php_zip
=======

php zip extension. Repository for the http://pecl.php.net/zip releases.

The zip extension is maintained in PECL for PHP 5 and 7
mostly for downstream distributions to keep in sync with libzip version.

Bundled libzip have been removed, only system library is supported.
